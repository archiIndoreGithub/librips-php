<?php

function xss($text) {
    echo $text;
}

xss($_GET['x']);
